# BASIC INTRODUCTION TO SIGMA JS IN JUPYTER NOTEBOOK AND NETWORK SCIENCE


This blog is a continuation of my previous blog on D3 in Jupyter Notebook, this blog will be using the basic concepts from the previous blog. I am going to introduce you guys ti networks and network diagrams using sigma js

The link to the blog : https://medium.com/@stallonejacob/basic-introduction-to-sigma-js-in-jupyter-notebook-and-network-science-7acddd52d53c
